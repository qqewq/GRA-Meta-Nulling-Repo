# ROS2 Integration

Each DomainNull runs as a ROS2 node.
Meta-null runs as coordinator.

Topics:
- /vision/psi
- /manipulation/psi
- /navigation/psi
