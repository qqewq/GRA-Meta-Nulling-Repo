# Grasp + Navigation Demo

Domains:
- Vision (object detection)
- Manipulation (grasp planning)
- Navigation (collision avoidance)

G_tot:
Execute grasp without human collision.

Expected:
Φ_local → 0
Φ_meta → 0
